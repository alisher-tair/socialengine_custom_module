<?php

class Guest_Model_DbTable_Blockedusers extends Engine_Db_Table
{
    protected $_rowClass = 'Guest_Model_Blockeduser';


}