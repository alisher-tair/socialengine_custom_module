<?php

class Guest_Model_DbTable_Allow extends Engine_Db_Table
{
    protected $_rowClass = 'Guest_Model_Allow';


}