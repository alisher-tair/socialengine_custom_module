<?php

class Guest_Model_Blockeduser extends Core_Model_Item_Abstract
{

}
