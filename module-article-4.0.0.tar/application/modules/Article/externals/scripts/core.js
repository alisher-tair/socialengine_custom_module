

var url = window.location.href;
url = url.split('?')[0];
url = url.split('/');
var lastSegment = url.pop() || url.pop();


switch (lastSegment) {
    case 'browse-articles': document.getElementById('browse-articles').addClass('active'); break;
    case 'my-articles': $('my-articles').getParent().addClass('active'); break;
    case 'create-article': $('create-article').getParent().addClass('active'); break;
}